//
//  AFAPIMarco.h
//  Mpos
//
//  Created by huazi on 14-10-21.
//  Copyright (c) 2014年 huifu. All rights reserved.
//

//#import "HZHTTPRequestSerializer.h"
//#import "HZMAPImanager.h"
//#import "HZMRequest.h"
//#import "HZMResponse.h"
#import "HZHTTPRequestSerializer.h"
#import "HZMAPImanager.h"
#import "HZMRequest.h"
#import "HZMResponse.h"

//#define kPitchList             @"10101"
//#define kPersonMessageAlter    @"10504"


#define kVersionUpdata      @"10601"
#define kLoginLogout        @"10602"
#define kCheckIn            @"10603"
#define kBeginEnd           @"10604"
#define kInputData          @"10605"
#define kPlaceNumInput      @"10606"
#define kDeviceInfo         @"10607"
#define kCheckInPeole       @"10608"
#define kActivityNum        @"10609"
#define kMatchPeopleList    @"10610"
#define kMatchPeopleInfo    @"10611"
#define kMatchDataLook      @"10612"
#define kMatchDataChange    @"10613"
#define kDirectDataCancel   @"10614"
#define kMatchDataDirect    @"10615"
#define kSureMatchData      @"10616"

//*******测试1*********
/**版本升级、*/
//#define SERVICE_URL @"https://121.41.33.76:8443/t98test/pages/ServerDispatch/doExecute.do"
//#define SERVICE_URL @"http://121.41.33.76:8180/t98test/pages/ServerDispatch/doExecute.do"
//#define SERVICE_FILE_URL @"https://121.41.33.76:8443/t98test/pages/ServerDispatch/doSendFile.do"

//*******测试2*********



//*******生产1*********


//*******生产2*********



//192.168.10.113
//#define SERVICE_URL             @"http://web.wdclc.cn"
#define SERVICE_URL             @"http://139.224.232.131:9081/web"

//#define SERVICE_URL             @"http://116.226.191.6:9081/web"
//#define SERVICE_URL             @"http://192.168.1.107:9081/web"
//#define SERVICE_Passort_URL     @"http://192.168.1.107:9080/passport"
//#define SERVICE_Passort_URL     @"http://passport.wdclc.cn"
#define SERVICE_Passort_URL     @"http://139.224.232.131:9080/passport/"

#define  SERVICE_FILE_URL       @""

#define kplaceholderImage  [UIImage imageNamed:@"teamPic"]
#define kplaceholderImageHostTeamPic   [UIImage imageNamed:@"HostTeamPic"]
#define kplaceholderImageGuestTeamPic   [UIImage imageNamed:@"GuestTeamPic"]
// 生产
//#define protocol_URL  @"https://121.41.33.76:8445/t98/apphtml/userAgree/userAgree.html"
//#define SERVICE_URL  @"https://121.41.33.76:8445/t98/pages/ServerDispatch/doExecute.do"
//#define SERVICE_FILE_URL @"https://121.41.33.76:8445/t98/pages/ServerDispatch/doSendFile.do"

//// 测试
//#define protocol_URL  @"https://121.41.33.76:8443/t98test/apphtml/userAgree/userAgree.html"
//#define SERVICE_URL  @"https://121.41.33.76:8443/t98test/pages/ServerDispatch/doExecute.do"
//#define SERVICE_FILE_URL @"https://121.41.33.76:8443/t98test/pages/ServerDispatch/doSendFile.do"

/*sina*/
#define Sina_APPKEY @"2437988923"
#define Sina_AppSecret @"8806a86cec0b851a9f53a58d11f15404"
/*微信*/

/*QQ*/
#define QQ_AppID @"1104935455"
#define QQ_App_Key @"oOR5IDPZpiOVrnHb"

