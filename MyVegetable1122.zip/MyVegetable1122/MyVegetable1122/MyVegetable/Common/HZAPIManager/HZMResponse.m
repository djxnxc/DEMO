//
//  HZMResponse.m
//  Mpos
//
//  Created by huazi on 14-10-21.
//  Copyright (c) 2014年 huifu. All rights reserved.
//

#import "HZMResponse.h"

@implementation HZMResponse

@end
