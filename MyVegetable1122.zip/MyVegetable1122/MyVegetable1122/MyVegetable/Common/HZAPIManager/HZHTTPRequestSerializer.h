//
//  HZHTTPRequestSerializer.h
//  Mpos
//
//  Created by huazi on 14-10-21.
//  Copyright (c) 2014年 huifu. All rights reserved.
//

#import "AFURLRequestSerialization.h"

@interface HZHTTPRequestSerializer : AFHTTPRequestSerializer

@end
