//
//  SSFPathLineLayer.h
//  RecoginizerPasswordDemo
//
//  Created by 施赛峰 on 14-7-21.
//  Copyright (c) 2014年 赛峰 施. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "SSFPasswordGestureView.h"

@interface SSFPathLineLayer : CALayer

@property (weak, nonatomic) SSFPasswordGestureView *passwordGestureView;

@property (assign, nonatomic) BOOL isWrong;

@end
