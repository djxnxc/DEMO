

#import <UIKit/UIKit.h>

@interface NSString (Extension)
- (CGSize)sizeWithFont:(UIFont *)font maxSize:(CGSize)maxSize;
+(NSString *)countNumAndChangeformat:(NSString *)num;
+ (NSString *)moneyString:(NSString *)str;
- (BOOL)isPureInt:(NSString*)string;
- (BOOL)isPureFloat:(NSString*)string;
+ (BOOL)textfieldHaveText:(UITextField *)textfield;
+ (NSString *)resetNSString:(NSString *)str;
+ (NSString *)SubWhiteSpaceString:(NSString *)str;
@end
