

#import <Foundation/Foundation.h>

@interface NSString (Zendai)
+ (NSString *)formatStringToDecimal:(NSString *)string digit:(NSInteger)digit decimalStyle:(BOOL)flag;
+ (NSString *)formatStringToDecimalWithPercent:(NSString *)string;
+ (NSString *)formatStringToBankNum:(NSString *)string;
+ (NSAttributedString *)attributeString:(NSString *)string fontSize:(NSUInteger)fontSize;
+ (NSAttributedString *)attributeColorString:(NSString *)string1 colorString:(NSString *)string2 fontSize:(NSUInteger)fontSize;
+(NSDictionary *)parseJSONStringToNSDictionary:(NSString *)JSONString;

@end
