
#import <Foundation/Foundation.h>

@interface NSString (Common)
+(NSString *)MD5:(NSString *)str;
+(NSString *)Base64encode:(NSString *)encodeStr;
+(NSString *)Base64decode:(NSString *)decodeStr;
+(BOOL) isEmpty:(NSString *) str;
+(BOOL)isValidateEmail:(NSString *)msg;
+(BOOL)isMobileNumber:(NSString *)mobileNum;
+(CGFloat)calculateTextHeight:(CGFloat)widthInput Content:(NSString *)strContent  font:(UIFont *)font;
+(CGFloat)calculateTextWidth:(CGFloat)widthInput Content:(NSString *)strContent  font:(UIFont *)font;
+(CGSize)calculateTextSize:(CGSize)size Content:(NSString *)strContent  font:(UIFont *)font;
+(BOOL)isStandardPassword:(NSString *)str andView:(UIView *)view;
+(BOOL)isStandardFargatherName:(NSString *)str andView:(UIView *)view;
+(NSString *)stringRemoveEmoji:(NSString *)stringRemoveEmoji;

@end
