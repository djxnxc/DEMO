//
//  PictureLabelBtn.h
//  QQZone
//
//  Created by mythkiven on 15/9/14.
//  Copyright (c) 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PictureLabelBtn : UIButton

@end
