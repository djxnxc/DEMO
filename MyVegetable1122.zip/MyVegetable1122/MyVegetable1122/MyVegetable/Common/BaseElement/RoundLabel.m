//
//  RoundLabel.m
//  T98
//
//  Created by mythkiven on 15/9/14.
//  Copyright (c) 2015年 yunhoo. All rights reserved.
//

#import "RoundLabel.h"

@implementation RoundLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 10;
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    self.layer.cornerRadius = 10;
}

@end
