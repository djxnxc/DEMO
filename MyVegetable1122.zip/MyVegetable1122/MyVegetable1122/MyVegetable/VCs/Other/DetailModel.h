//
//  DetailModel.h
//  MyVegetable
//
//  Created by mythkiven on 15/12/10.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DetailModel : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *content;

@end
