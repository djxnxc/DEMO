//
//  DetailVCSubOne.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/26.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailVCSubOne : UIViewController
@property (nonatomic, assign) NSInteger pageNum;
@property (nonatomic, assign) NSInteger scrollNum;
@property (nonatomic, strong) NSString *productId;
@end
