//
//  FirstUserView.h
//  MyVegetable
//
//  Created by apple on 16/1/6.
//  Copyright © 2016年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstUserView : UIView<UIScrollViewDelegate>
{
    UIWindow* win;
    
}
@property (strong, nonatomic) IBOutlet UIPageControl *page;
@property (strong, nonatomic) IBOutlet UIScrollView *useScroller;
- (IBAction)clickBtn:(id)sender;
-(id)initWithNib;
@property (strong, nonatomic) IBOutlet UIButton *btn;
-(void)show;
-(void)dissmes;
@end
