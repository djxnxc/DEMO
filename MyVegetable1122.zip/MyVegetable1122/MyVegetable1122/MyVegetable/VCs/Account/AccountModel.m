//
//  AccountModel.m
//  MyVegetable
//
//  Created by mythkiven on 15/11/16.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import "AccountModel.h"

@implementation AccountModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{}
@end
