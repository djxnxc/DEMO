//
//  AccountDQSubOne.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/23.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountJLSubOne : UIViewController
@property (nonatomic, assign) NSInteger pageNum;
//@property (nonatomic, strong) NSMutableArray *data;
-(void)setTableViewRect:(CGRect)frame;
@end
