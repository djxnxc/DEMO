//
//  AccountHQCellModel.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/21.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AccountHQCellModel : NSObject
@property (nonatomic, copy) NSString *time;
@property (nonatomic, copy) NSString *monkey;
/**操作方式*/
@property (nonatomic, copy) NSString *style;
/**收益*/
@property (nonatomic, copy) NSString *monkeyGet;
-(instancetype)initWithDic:(NSDictionary*)dic;
@end
