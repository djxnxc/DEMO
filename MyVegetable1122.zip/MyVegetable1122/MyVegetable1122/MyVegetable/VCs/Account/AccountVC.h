//
//  AccountVC.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/11.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountVC : UIViewController
@property (nonatomic, copy) NSString *urlStr;
@end
