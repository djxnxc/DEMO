//
//  AccountDQModel.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/24.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AccountJLModel : NSObject

@property (copy, nonatomic) NSString *type;

@property (copy, nonatomic) NSString *monkey;
/**0 未 1 已经*/
@property (copy, nonatomic) NSString *isUseOrold;
@property(strong,nonatomic) NSString* statusName;

@property (copy, nonatomic) NSString *from;

@property (copy, nonatomic) NSString *effect;
@property (copy, nonatomic) NSString *condition;
@property (copy, nonatomic) NSString *status;
- (id)initWithDic:(NSDictionary *)dic;
@end
