//
//  Province.h
//  UIPickerVIew_City
//
//  Created by qianfeng on 15/6/24.
//  Copyright (c) 2015年 yangxin. All rights reserved.
//  省份模型

#import <Foundation/Foundation.h>

@interface Province : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString  *ID;
@property (nonatomic, strong) NSString  *no;

// 初始化方法
//- (instancetype)initWithName:(NSString *)name cities:(NSArray *)cities;
- (instancetype)initWithDic:(NSDictionary *)dic;
//+ (instancetype)provinceWithName:(NSString *)name cities:(NSArray *)cities;
@end
