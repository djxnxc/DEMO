//
//  AccountHQShuhui.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/21.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

//#import "AccountBaseVC.h"

//@interface AccountJLTiXian : AccountBaseVC
//@property (nonatomic, strong) id  del;
//@end

#import <UIKit/UIKit.h>
@interface AccountJLTiXian : UIViewController
@property (nonatomic, strong) id  del;
@property (nonatomic, assign) NSInteger  isfrom;
@property (nonatomic, assign) NSInteger  totalNum;
@end
