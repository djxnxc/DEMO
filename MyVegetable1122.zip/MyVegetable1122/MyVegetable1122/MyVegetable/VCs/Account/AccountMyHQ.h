//
//  AccountMyHQ.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/21.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

//#import "AccountBaseVC.h"
//
//@interface AccountMyHQ : AccountBaseVC

#import <UIKit/UIKit.h>

@interface AccountMyHQ : UIViewController
@property (nonatomic, strong) id  del;
@end
