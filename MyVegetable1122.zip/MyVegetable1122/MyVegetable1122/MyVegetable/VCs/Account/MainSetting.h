//
//  MainSetting.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/20.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainSetting : UIViewController
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) UIButton *btn;
@property (strong, nonatomic) NSMutableArray *data;
- (void)didClickedBtn;
@end
