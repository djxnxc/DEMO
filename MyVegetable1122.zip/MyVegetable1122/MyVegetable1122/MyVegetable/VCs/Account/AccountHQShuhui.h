//
//  AccountHQShuhui.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/21.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import "AccountBaseVC.h"

@interface AccountHQShuhui : AccountBaseVC
@property (nonatomic, strong) id  del;
@end
