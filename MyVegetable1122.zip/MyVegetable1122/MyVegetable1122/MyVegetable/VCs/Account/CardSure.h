//
//  CardSure.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/20.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardSure : UIViewController
//是否从充值那边跳转过来的:1。 用户判断是否要跳入银行卡绑定。
@property (nonatomic, assign) NSInteger isform;
@end
