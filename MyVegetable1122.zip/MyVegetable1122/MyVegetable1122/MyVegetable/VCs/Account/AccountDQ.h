//
//  AccountDQ.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/23.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountDQ : UIViewController
@property (nonatomic, copy) NSString *urlStr;
@property (nonatomic, assign) NSInteger num;
 
@end
