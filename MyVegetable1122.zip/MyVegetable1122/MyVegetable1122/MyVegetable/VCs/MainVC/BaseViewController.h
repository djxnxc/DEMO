//
//  BaseViewController.h
//  LoveXianMian
//
//  Created by 蒋孝才 on 15/7/1.
//  Copyright (c) 2015年 蒋孝才. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UINavigationController
@property (nonatomic, copy) NSString *urlStr;

@end
//设置导航控制器