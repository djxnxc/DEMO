//
//  SetUpTrPasswordViewController.h
//  MyVegetable
//
//  Created by apple on 16/1/14.
//  Copyright © 2016年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HZMAPImanager.h"
#import "WDCAccount.h"
@interface SetUpTrPasswordViewController : UIViewController<HZMAPIManagerDelegate,UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *password;
@property (strong, nonatomic) IBOutlet UITextField *rePassword;
@property (strong, nonatomic) IBOutlet UIButton *shureBtn;

- (IBAction)submit:(id)sender;

- (IBAction)backRoot:(id)sender;
@end
