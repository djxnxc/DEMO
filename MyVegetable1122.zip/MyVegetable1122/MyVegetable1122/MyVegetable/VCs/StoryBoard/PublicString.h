//
//  PublicString.h
//  MyVegetable
//
//  Created by apple on 15/12/31.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HZMAPImanager.h"
@interface PublicString : NSObject
@property(nonatomic,assign)BOOL isTrueName;
@property(nonatomic,assign)BOOL isTransPassword;
-(void)checkInfo;
-(void)checkPassword;
+(NSString*)stringToMoney:(NSString*)money;
+(id)shareSDK;
@end
