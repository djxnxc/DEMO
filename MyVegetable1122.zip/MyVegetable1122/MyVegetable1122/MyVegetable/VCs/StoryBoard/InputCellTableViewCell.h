//
//  InputCellTableViewCell.h
//  MyVegetable
//
//  Created by apple on 15/12/29.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputCellTableViewCell : UITableViewCell


@property (strong, nonatomic) IBOutlet UIImageView *rightArraw;
@property (strong, nonatomic) IBOutlet UITextField *input;
@property (strong, nonatomic) IBOutlet UILabel *cardTitle;
@property (strong, nonatomic) IBOutlet UIImageView *cardImage;
-(id)initWithNib;

@end
