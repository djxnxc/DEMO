//
//  InputCellTableViewCell.m
//  MyVegetable
//
//  Created by apple on 15/12/29.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import "InputCellTableViewCell.h"

@implementation InputCellTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(id)initWithNib
{
    NSArray* array=[[NSBundle mainBundle]loadNibNamed:@"subInputCell" owner:self options:nil];
    self =[array firstObject];
    return self;
}
@end
