//
//  WebHtml5ViewController.h
//  MyVegetable
//
//  Created by apple on 16/1/13.
//  Copyright © 2016年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebHtml5ViewController : UIViewController<UIWebViewDelegate,UMSocialDataDelegate,UMSocialUIDelegate,HZMAPIManagerDelegate>

@property (strong, nonatomic) IBOutlet UILabel *titleLable;
@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property(nonatomic,strong)NSString* url;
@property(nonatomic,strong)NSString* messTitle;
@property(nonatomic,strong)NSDictionary* dict;
@property(nonatomic,assign)int type;
@property(nonatomic,strong)NSString* myCode;
- (IBAction)backBtn:(id)sender;

@end
