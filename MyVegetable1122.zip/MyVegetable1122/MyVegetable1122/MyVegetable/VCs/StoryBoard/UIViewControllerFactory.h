//
//  UIViewControllerFactory.h
//  MyVegetable
//
//  Created by apple on 15/12/29.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WebHtml5ViewController.h"
#import <UIKit/UIKit.h>
#import "AccountTiXianViewController.h"
#import "SetUpTrPasswordViewController.h"
#import "P6HomePageViewController.h"
#define ACCOUNT_UI_TIXIAN @"account_tixian"
#define HTML5_WebView @"webView"
#define Trad_Password @"TradPassword"
#define P6_HomePage @"p6HomePage"
@interface UIViewControllerFactory : NSObject

+(id)getViewController:(NSString*)ident;
@end
