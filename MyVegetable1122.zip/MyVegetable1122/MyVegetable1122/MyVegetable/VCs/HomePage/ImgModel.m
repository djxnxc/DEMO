//
//  ImgModel.m
//  MyVegetable
//
//  Created by mythkiven on 15/12/13.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import "ImgModel.h"

@implementation ImgModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{}
@end
