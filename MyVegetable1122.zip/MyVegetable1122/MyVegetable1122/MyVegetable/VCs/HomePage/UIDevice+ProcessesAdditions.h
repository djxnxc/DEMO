//
//  UIDevice+ProcessesAdditions.h
//  ProgressViewDemo
//
//

#import <UIKit/UIKit.h>

@interface UIDevice (ProcessesAdditions)
- (NSArray *)runningProcesses;
@end
