//
//  HtmlZP.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/30.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HtmlZP : UIViewController
@property(nonatomic,strong)NSString* address;
@property(nonatomic,strong)NSString* webTitle;
@end
