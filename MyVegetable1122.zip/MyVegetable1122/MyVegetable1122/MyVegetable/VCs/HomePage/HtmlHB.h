//
//  HtmlHB.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/30.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HtmlHB : UIViewController
@property(strong,nonatomic)NSString* url;
@property(strong,nonatomic)NSString* webTitle;
@end
