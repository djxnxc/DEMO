//
//  LoginMima.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/20.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoseLoginReset : UIViewController
@property (nonatomic, strong) id  some;
@property (nonatomic, strong) NSString *phoneNum;
@property (nonatomic, strong) NSString *code;
@end
