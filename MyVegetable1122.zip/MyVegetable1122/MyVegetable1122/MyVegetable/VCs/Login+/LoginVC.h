//
//  LoginVC.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/25.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController
/**
99 手势密码
88 首页
76 理财活期
77 理财定期
78 理财新手标
66 账户
22 来自注册完成
111 忘记手势密码-修改
112 忘记手势密码-是否重设
 */
@property (nonatomic,strong)UINavigationController* nc;
@property (nonatomic, assign) NSInteger isFrom;
@property (nonatomic, strong) id  some;
@end
