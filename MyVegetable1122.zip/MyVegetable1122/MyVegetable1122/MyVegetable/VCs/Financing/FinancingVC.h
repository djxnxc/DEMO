//
//  FinancingVC.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/11.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinancingVC : UIViewController
@property (nonatomic, copy) NSString *urlStr;
//滚到哪一个 页面 默认0 ：中间定期 99 左边的页面 101 右边页面
@property (nonatomic, assign) NSInteger num;
//从哪里来的
@property (nonatomic, assign) BOOL isfrom;

@end
