//
//  TransData.h
//  MyVegetable
//
//  Created by mythkiven on 15/12/14.
//  Copyright © 2015年 yunhoo. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface TransData : NSObject
+ (NSInteger)transViewSindex:(UIView *)view arr:(NSMutableArray *)useData;
+ (NSInteger)transViewIndex:(UIView *)view arr:(NSMutableArray *)useData;
@end
