//
//  DingLICAIModel.m
//  MyVegetable
//
//  Created by mythkiven on 15/11/19.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import "DingLICAIModel.h"

@implementation DingLICAIModel

@end
