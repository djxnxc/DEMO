//
//  Tiyanjin.h
//  MyVegetable
//
//  Created by mythkiven on 15/12/21.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tiyanjin : NSObject
@property (nonatomic, strong) NSString *couponId;
@property (nonatomic, strong) NSString *amount;
@property(nonatomic,assign)int status;
@property(nonatomic,strong) NSString* getMode;
- (id)initWithDic:(NSDictionary *)dic;
@end
