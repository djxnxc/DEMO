//
//  LoginVC.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/25.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuyOne : UIViewController
/**来自的地方   活期22 定期 23 新手标 24*/
@property (nonatomic, assign) NSInteger isfrom;


@property (nonatomic, copy) NSString* name;
@property (nonatomic, copy) NSString* myMoney;
@property (nonatomic, copy) NSString* canBuy;
@property (nonatomic, assign)CGFloat minInterest;
@property (nonatomic, copy) NSString* minInvestAmount;
@property (nonatomic, copy) NSString* ProdctID;
@property (nonatomic, copy) NSString* maxInvestAmount;
@property (nonatomic, strong) NSMutableArray *data;
//@property (nonatomic, assign) long long proId;
@end
