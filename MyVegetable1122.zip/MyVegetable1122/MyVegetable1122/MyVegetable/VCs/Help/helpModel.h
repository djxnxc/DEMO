//
//  helpModel.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/16.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface helpModel : NSObject
@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *detailTitle;
@property (nonatomic, copy) NSString *imageNext;
- (void)initWithDic:(NSDictionary *)dic;
@end
