//
//  AnQuanBZ.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/17.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnQuanBZ : UITableViewController

@end
