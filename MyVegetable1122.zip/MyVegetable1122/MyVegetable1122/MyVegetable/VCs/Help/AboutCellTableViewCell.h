//
//  AboutCellTableViewCell.h
//  MyVegetable
//
//  Created by apple on 16/1/18.
//  Copyright © 2016年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutCellTableViewCell : UITableViewCell

-(id)initWithNib;
-(void)setKey:(NSString*)key the:(NSString*)value;
@end
