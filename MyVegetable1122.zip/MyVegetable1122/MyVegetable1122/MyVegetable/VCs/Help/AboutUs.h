//
//  AboutUs.h
//  MyVegetable
//
//  Created by mythkiven on 15/12/1.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AboutCellTableViewCell.h"
@interface AboutUs : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSDictionary* dict;
}
@property (strong, nonatomic) IBOutlet UITableView *tableUS;

@end
