//
//  WeChart.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/17.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeChart : UIViewController
{
    int index;
}
@property (strong, nonatomic) IBOutlet UIImageView *wxdyh;
@property (strong, nonatomic) IBOutlet UIImageView *wxfwh;

@end
