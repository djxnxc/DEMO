//
//  JFriendsPageVC.h
//  QQ好友页面
//
//  Created by 蒋孝才 on 15/7/23.
//  Copyright (c) 2015年 JXC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangJianWT : UITableViewController

@end
