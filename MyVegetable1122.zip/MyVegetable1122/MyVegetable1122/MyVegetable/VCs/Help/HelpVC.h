//
//  HelpVC.h
//  MyVegetable
//
//  Created by mythkiven on 15/11/11.
//  Copyright © 2015年 yunhoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpVC : UIViewController
@property (nonatomic, copy) NSString *urlStr;
@property(nonatomic,strong) NSString* myCode;
@end
